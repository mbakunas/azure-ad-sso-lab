﻿configuration FormatDisk
{ 
    Import-DscResource -ModuleName xStorage

    Node 'localhost'
    {

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec = 30
             RetryCount = 20
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = 'F'
            FSLabel = 'Data'
        }

    }
}
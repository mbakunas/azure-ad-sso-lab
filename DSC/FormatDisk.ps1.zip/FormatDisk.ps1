﻿configuration FormatDisk
{ 
    Import-DscResource -ModuleName StorageDsc

    Node 'localhost'
    {

        WaitforDisk Disk2
        {
             DiskId = 2
             RetryIntervalSec = 30
             RetryCount = 20
        }

        Disk ADDataDisk
        {
            DiskId = 2
            DriveLetter = 'F'
            FSLabel = 'Data'
        }

    }
}
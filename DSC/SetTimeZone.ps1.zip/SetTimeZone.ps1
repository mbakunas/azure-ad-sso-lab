﻿Configuration setTimeZone
{
    param
    (
        [Parameter(Mandatory)]
        [String]$timeZone
    )
    Import-DSCResource -ModuleName ComputerManagementDsc

    $allowedTimeZones = (Get-TimeZone -ListAvailable).Id
    if ($timeZone -notin $allowedTimeZones) {$timeZone = 'Eastern Standard Time'}

    Node localhost
    {
        TimeZone TimeZoneExample
        {
            IsSingleInstance = 'Yes'
            TimeZone         = $timeZone
        }
    }
}
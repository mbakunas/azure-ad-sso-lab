﻿configuration MakeDC
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,


        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc, StorageDsc

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)
    
    
    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true
        }

        WaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        Disk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = 'F'
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }  

        # Optional GUI tools
        WindowsFeature ADDSTools
        { 
            Ensure = 'Present' 
            Name = 'RSAT-ADDS' 
        }

        ADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = 'F:\NTDS'
            LogPath = 'F:\NTDS'
            SysvolPath = 'F:\SYSVOL'
            DependsOn = "[WindowsFeature]ADDSInstall","[Disk]ADDataDisk"
        }

        WaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[ADDomain]FirstDS"
        } 

        ADOptionalFeature RecycleBin
        {
           FeatureName = "Recycle Bin Feature"
           EnterpriseAdministratorCredential = $DomainCreds
           ForestFQDN = $DomainName
           DependsOn = '[WaitForADDomain]DscForestWait'
        }

#region OUs
        
        $domainRoot = "DC=$($DomainName -replace '\.',',DC=')"

        ADOrganizationalUnit OU_Corp
        {
            Name = 'Corp'
            Path = $domainRoot
            ProtectedFromAccidentalDeletion = $true
            Description = 'OU for corporate users, groups, and computers'
            Credential = $DomainCreds
            Ensure = 'Present'
            DependsOn = '[ADOptionalFeature]RecycleBin'
        }

        
        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs)
        {
            ADOrganizationalUnit "OU_$RootOU"
            {
                Name = $RootOU
                Path = "OU=Corp,$domainRoot"
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for Corporate $RootOU"
                Credential = $DomainCred
                Ensure = 'Present'
                DependsOn = '[ADOrganizationalUnit]OU_Corp'
            }

            ForEach ($dept in $ConfigurationData.NonNodeData.Departments)
            {
                
                xADOrganizationalUnit "OU_$($RootOU)_$dept"
                {
                    Name = $dept
                    Path = "OU=$RootOU,OU=Corp,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Description = "OU for $dept $RootOU"
                    Credential = $DomainCred
                    Ensure = 'Present'
                    DependsOn = "[ADOrganizationalUnit]OU_$RootOU"
                }
            }
        }

#endregion

#region users

        $DependsOn_User = @()
        $Users = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        ForEach ($User in $Users)
        {
            if ($user.Manager -ne '')
            {
                ADUser "NewADUser_$($User.UserName)"
                {
                    DomainName = $DomainName
                    Ensure = 'Present'
                    CommonName = $User.UserName
                    Department = $User.Dept
                    DisplayName = $User.DisplayName
                    UserName = $User.UserName
                    GivenName = $User.GivenName
                    JobTitle = $User.JobTitle
                    Surname = $User.Surname
                    Manager = "CN=$($User.Manager),OU=$($User.Dept),OU=Users,OU=Corp,$DomainRoot" 
                    UserPrincipalName = "$($User.UserName)@$DomainName"
                    Path = "OU=$($User.Dept),OU=Users,OU=Corp,$DomainRoot"
                    Enabled = $true
                    Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                    DependsOn = "[ADOrganizationalUnit]OU_Users_$($User.Dept)","[ADUser]NewADUser_$($User.Manager)"
                }
            }
            else
            {
                ADUser "NewADUser_$($User.UserName)"
                {
                    DomainName = $DomainName
                    Ensure = 'Present'
                    CommonName = $User.UserName
                    Department = $User.Dept
                    DisplayName = $User.DisplayName
                    UserName = $User.UserName
                    GivenName = $User.GivenName
                    JobTitle = $User.JobTitle
                    Surname = $User.Surname
                    UserPrincipalName = "$($User.UserName)@$DomainName"
                    Path = "OU=$($User.Dept),OU=Users,OU=Corp,$DomainRoot"
                    Enabled = $true
                    Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                    DependsOn = "[ADOrganizationalUnit]OU_Users_$($User.Dept)"
                }
            }
            $DependsOn_User += "[ADUser]NewADUser_$($User.UserName)"
        }

#endregion

#region groups
        ForEach ($dept in $ConfigurationData.NonNodeData.Departments)
        {
            ADGroup "NewADGroup_$dept"
            {
                GroupName = "$dept"
                GroupScope = 'Global'
                Description = "Global group for $dept"
                Category = 'Security'
                Members = ($Users | Where-Object {$_.Dept -eq $dept}).UserName
                Path = "OU=$dept,OU=Groups,OU=Corp,$DomainRoot"
                Ensure = 'Present'
                DependsOn = $DependsOn_User
            }
        }
#endregion

    }
}
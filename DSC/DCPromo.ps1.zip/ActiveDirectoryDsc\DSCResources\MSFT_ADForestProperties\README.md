# Description

The ADForestProperties DSC resource will manage forest wide settings within an Active Directory forest.
These include User Principal Name (UPN) suffixes, Service Principal Name (SPN) suffixes and the tombstone lifetime.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
